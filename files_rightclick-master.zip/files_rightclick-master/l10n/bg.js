OC.L10N.register(
    "files_rightclick",
    {
    "Unselect" : "Размаркирай",
    "Share " : "Сподели",
    "Select" : "Избери",
    "Copied !" : "Копирано!",
    "Right click" : "Десен бутон"
},
"nplurals=2; plural=(n != 1);");
