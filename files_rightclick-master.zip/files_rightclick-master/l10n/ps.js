OC.L10N.register(
    "files_rightclick",
    {
    "Unselect" : "سشیبشسیب",
    "Select" : "ټاکل"
},
"nplurals=2; plural=(n != 1);");
