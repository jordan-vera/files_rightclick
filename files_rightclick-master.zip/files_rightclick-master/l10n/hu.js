OC.L10N.register(
    "files_rightclick",
    {
    "Unselect" : "Kiválasztás megszüntetése",
    "Share " : "Megosztás",
    "Select" : "Kiválasztás",
    "Copied !" : "Másolva.",
    "Right click" : "Jobb gomb",
    "Right click menu for Nextcloud" : "Jobb gombos menü a Nextcloudhoz",
    "This app allows users and developers to have a right click menu. Simply use the RightClick object to quickly create context menus. The Files app already shows the actions menu when right clicking on files and folders." : "Ezzel az alkalmazással a felhasználók és fejlesztők jobb gombos menüt kapnak. Egyszerűen használja a RightClick objektumot, hogy gyorsan hozzon létre környezeti menüket. A Fájlok alkalmazás már megjeleníti a műveleteket, ha jobb gombbal kattint a fájlokra és mappákra."
},
"nplurals=2; plural=(n != 1);");
