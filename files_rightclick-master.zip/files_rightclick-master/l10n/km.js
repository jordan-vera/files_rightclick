OC.L10N.register(
    "files_rightclick",
    {
    "Select" : "Select"
},
"nplurals=1; plural=0;");
