OC.L10N.register(
    "files_rightclick",
    {
    "Select" : "সিলেক্ট"
},
"nplurals=2; plural=(n != 1);");
