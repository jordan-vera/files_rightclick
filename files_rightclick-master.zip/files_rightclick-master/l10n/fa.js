OC.L10N.register(
    "files_rightclick",
    {
    "Unselect" : "لغو انتخاب",
    "Share " : "اشتراک گذاری",
    "Select" : "انتخاب",
    "Copied !" : "کپی شد!",
    "Right click" : "کلیک راست",
    "Right click menu for Nextcloud" : "منوی کلیک راست برای Nextcloud",
    "This app allows users and developers to have a right click menu. Simply use the RightClick object to quickly create context menus. The Files app already shows the actions menu when right clicking on files and folders." : "این برنامه به کاربران و توسعه دهندگان اجازه می دهد منوی کلیک راست داشته باشند. نگران نباشید ،به سادگی کلیک  تا به سرعت فهرست های زمینه ایجاد شود. برنامه Files قبلاً با کلیک راست بر روی پرونده ها و پوشه ها ، فهرست عملکردها را نشان می دهد."
},
"nplurals=2; plural=(n > 1);");
