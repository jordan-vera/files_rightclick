OC.L10N.register(
    "files_rightclick",
    {
    "Select" : "Сонгох"
},
"nplurals=2; plural=(n != 1);");
