OC.L10N.register(
    "files_rightclick",
    {
    "Unselect" : "Desautatu",
    "Share " : "Partekatu",
    "Select" : "Hautatu",
    "Copied !" : "Kopiatuta !",
    "Right click" : "Klik eskuineko botoiarekin",
    "Right click menu for Nextcloud" : "Egin klik eskuineko botoiarekin menuan Nextcloud-entzat"
},
"nplurals=2; plural=(n != 1);");
