OC.L10N.register(
    "files_rightclick",
    {
    "Select" : "Vali"
},
"nplurals=2; plural=(n != 1);");
