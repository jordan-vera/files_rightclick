OC.L10N.register(
    "files_rightclick",
    {
    "Unselect" : "Поништи избор",
    "Share " : "Сподели",
    "Select" : "Select",
    "Copied !" : "Копирано !",
    "Right click" : "Десен клик",
    "Right click menu for Nextcloud" : "Десен клик мени за Nextcloud"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
