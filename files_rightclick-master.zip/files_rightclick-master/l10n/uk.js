OC.L10N.register(
    "files_rightclick",
    {
    "Unselect" : "Зняти виділення",
    "Share " : "Поширити",
    "Select" : "Вибрати",
    "Copied !" : "Скопійовано!",
    "Right click" : "Права кнопка",
    "Right click menu for Nextcloud" : "Меню правої кнопки для Nextcloud",
    "This app allows users and developers to have a right click menu. Simply use the RightClick object to quickly create context menus. The Files app already shows the actions menu when right clicking on files and folders." : "Цей застосунок дозволяє користувачам і розробникам створювати і використовувати меню правої кнопки. Використовуйте об'єкт RightClick для швидкого створення контекстного меню. У застосунку Файли меню правої кнопки вже використовується для файлів і тек."
},
"nplurals=4; plural=(n % 1 == 0 && n % 10 == 1 && n % 100 != 11 ? 0 : n % 1 == 0 && n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 12 || n % 100 > 14) ? 1 : n % 1 == 0 && (n % 10 ==0 || (n % 10 >=5 && n % 10 <=9) || (n % 100 >=11 && n % 100 <=14 )) ? 2: 3);");
