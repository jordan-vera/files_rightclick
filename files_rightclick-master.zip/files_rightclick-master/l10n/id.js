OC.L10N.register(
    "files_rightclick",
    {
    "Select" : "Pilih"
},
"nplurals=1; plural=0;");
