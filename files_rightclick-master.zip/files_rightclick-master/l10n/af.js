OC.L10N.register(
    "files_rightclick",
    {
    "Select" : "Kies"
},
"nplurals=2; plural=(n != 1);");
