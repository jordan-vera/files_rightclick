OC.L10N.register(
    "files_rightclick",
    {
    "Unselect" : "Velg bort",
    "Share " : "Del",
    "Select" : "Velg",
    "Copied !" : "Kopiert!",
    "Right click" : "Høyreklikk",
    "Right click menu for Nextcloud" : "Høyreklikksmeny for Nextcloud"
},
"nplurals=2; plural=(n != 1);");
